# Guidelines for Contribution  

### This Repository Contains resources for college grads and professionals around the world to get involved in opportunties around you apart from academics. 

1. Checkout [README.md](README.md) for list of resources.

2. Add resources which you think should be useful for others. It can be anything like coding resources, hackathons, events, scholarships or Internship.

3. Please don't remove any resources or content from README.md

4. Make sure to add your resources in correct section as mentioned in Table of Content. 
5. Please verify resources and put them in the right topic.
